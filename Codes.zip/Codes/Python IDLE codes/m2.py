import pandas as pd
import numpy as np

import smtplib
from email.message import EmailMessage
import imghdr
email_add = 'karthickhit0307@gmail.com'
email_pass = "karthickvgk"
msg = EmailMessage()
msg['Subject'] = "Crop Type"
msg['From'] = email_add
msg['To'] = email_add
msg.set_content("Rice")

def email():
        with smtplib.SMTP_SSL('smtp.gmail.com',465)as smtp:
            smtp.login(email_add,email_pass)
            smtp.send_message(msg)
dataset = pd.read_csv("crop.csv")
print(dataset)
print(dataset.shape)
print(dataset.describe())

x = dataset.iloc[: ,0:5].values
y = dataset.iloc[:,5].values


print(x)
print(y)
from sklearn.preprocessing import LabelEncoder
labelencoder_y=LabelEncoder()
y=labelencoder_y.fit_transform(y)
print(y)

print("x=",x)
print("y=",y)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x ,y, test_size = 0.2 ,random_state = 0)

print("x_train=",x_train)
print("x_test=",x_test)
print("y_train=",y_train)
print("y_test=",y_test)

from sklearn.neighbors import KNeighborsClassifier
knn=KNeighborsClassifier(n_neighbors=3)
knn.fit(x_train,y_train)
print('KNeighborsClassifier Training Accuracy:', knn.score(x_train, y_train))

y_pred=knn.predict(x_test)
print("y_pred",y_pred)

from sklearn.metrics import classification_report,confusion_matrix
print(confusion_matrix(y_test,y_pred))
print(classification_report(y_test,y_pred))

print("Testing Accuracy")
from sklearn import metrics
#Model Accuracy, how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))

a= knn.predict([[35,66,15,0,0]])
print('Predicted new output value: %s' % (a))

import serial
ser = serial.Serial('COM3',baudrate=9600,timeout=2)
import pandas as pd
import numpy as np

dataset = pd.read_csv("leaf.csv")
#print(dataset)

x = dataset.iloc[: ,0:2].values
y = dataset.iloc[:, 2].values

#print(x)
#print(y)

from sklearn.preprocessing import LabelEncoder
labelencoder_y=LabelEncoder()
y=labelencoder_y.fit_transform(y)
print(y)

#print("x=",x)
#print("y=",y)


from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x ,y, test_size = 1/7 ,random_state = 0)
"""
print("x_train=",x_train)
print("x_test=",x_test)
print("y_train=",y_train)
print("y_test=",y_test)
"""
from sklearn.neighbors import KNeighborsClassifier
classifier=KNeighborsClassifier(n_neighbors=5)
classifier.fit(x_train,y_train)
print('KNeighborsClassifier Training Accuracy:', classifier.score(x_train, y_train))

y_pred=classifier.predict(x_test)
print("y_pred",y_pred)

from sklearn.metrics import classification_report,confusion_matrix
print(confusion_matrix(y_test,y_pred))
print(classification_report(y_test,y_pred))

print("Testing Accuracy")
from sklearn import metrics
#Model Accuracy, how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y_test, y_pred))

import cv2
img = cv2.imread("b.jpg")
#img = cv2.resize(img,(150,150))
cv2.imshow("imgd",img)
hsv = cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
cv2.imshow("hsv",hsv)
mask1 = cv2.inRange(hsv,(36,100,50),(90,255,255))
cv2.imshow("mask1",mask1)

mask = cv2.bitwise_or(mask1,mask1)
ma1 = cv2.bitwise_and(img,img,mask=mask)


cv2.imwrite("tar.png",ma1)
cv2.imshow("final",ma1)
Contours,_ =cv2.findContours(mask,1,2)
for contour in Contours:
    cv2.drawContours(img,Contours,-1,(0,0,0),2)
    cv2.imshow("cont",img)
j=0
temp=0
for i in range(10):
    try:
        area= cv2.contourArea(Contours[i])
        print(area)
        temp=temp+area
       
    except:
        pass
print(len(Contours))
print(j)        
print(temp)

while True:
    a=ser.readline().decode('ascii')
    print('yes')
    print(a)
    b=a
    for letter in b:
        if(letter == 'T'):
            D1 = b[1]+b[2]+b[3]
            T = int(D1)
        if(letter == 'N'):
            D2 = b[5]+b[6]+b[7]
        if(letter == 'S'):
            D3 = b[9]+b[10]+b[11]
        if(letter == 'H'):
            D4 =b[13]+b[14]+b[15]
        if(letter == 'P'):
            D5 =b[17]+b[18]
            Temp = int(D1)
            NPK = int(D2)
            Soil = int(D3)
            Humidity = int(D4)
            pH = int(D5)
            print("Temperature:",Temp)
            print("NPK:",NPK)
            print("Soil Moisture:",Soil)
            print("Humidity:" ,Humidity)
            print("pH:", pH)
        
            a= knn.predict([[Temp,NPK,Soil,Humidity,pH]])
            print('Predicted new output value: %s' % (a))
        
            if (a==2):
                ser.write('C'.encode())
                print("Dhal")
##                msg.set_content("Dhal")
##                email()
                
            elif(a==1):
                ser.write('B'.encode())
                print(" Maize ")
##                msg.set_content("Maize")
##                email()

            elif(a==0):
                ser.write('A'.encode())
                print(" RICE ")
##                msg.set_content("RICE")
##                email()
               
            else:
                ser.write('D'.encode())
                print("All the Above")
            R=classifier.predict([[temp,j]])
            print(a)
            if (R==3):
                    print("heavily  spreaded")
                    ser.write('E'.encode())
                    print('send')
            elif(R==2):
                    print("slightly affected")
                    ser.write('E'.encode())
                    print('send')
            elif(R==1):
                    print("mediumly spreaded")
                    ser.write('E'.encode())
                    print('send')
            else:
                    print("normal")

        ser.write('F'.encode())



